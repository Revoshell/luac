script_name('ML-ReloadAll')
script_author('FYP')
script_description('Press Ctrl + R to reload all lua scripts. Also can be used to load new added scripts')
if script_properties then
	script_properties('work-in-pause', 'forced-reloading-only')
end


function main()
	if not isSampfuncsLoaded() or not isSampLoaded() then return end
	while not isSampAvailable() do wait(0) end
	while true do wait(40)
		if check() then
			if isKeyDown(17) and isKeyDown(82) then
				reloadScripts()
			end
		end
	end
end

function check()
	return not isSampfuncsConsoleActive() and not sampIsDialogActive() and not sampIsChatInputActive()
end